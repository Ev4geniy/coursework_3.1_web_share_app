package my.cursework.controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import my.cursework.model.FilesystemNode;
import my.cursework.model.MysqlManager;

import java.io.IOException;

public class ShareToAll extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String filename = request.getParameter("filename");
        HttpSession sess = request.getSession();
        String username = (String) sess.getAttribute("username");
        int uid = (int) sess.getAttribute("uid");
        FilesystemNode root = (FilesystemNode)request.getSession().getAttribute("tree");

        String file = request.getParameter("filename");
        System.out.println("SHARETOALL:request to share"+file);
        if ( file == null || file.isEmpty()){
            file = "/"+username +"/";
            System.out.println("SHARETOALL: file is null");
            response.setStatus(418);
            return;
        }
        String [] splitPath= file.split("/");

        FilesystemNode target = root;
        System.out.println(target.toStringTerminal());

        for (String it: splitPath){
            if(!it.equals("/") && !it.isEmpty()){
                target = target.getChild(it);
                System.out.println(it);
            }
        }
        System.out.println("SHARETOAAL: attempt to share: "+target.getFullName());
        MysqlManager mysqlManager = new MysqlManager();
        FilesystemNode publicRoot = new FilesystemNode("public",0);
        publicRoot.addPublicChild(target);
        String hash = mysqlManager.addPublicFile(username, filename, publicRoot);
        mysqlManager.close();
        if (hash != null){
            response.getWriter().println(hash);
        }
    }
}
