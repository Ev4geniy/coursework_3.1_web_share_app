package my.cursework.controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import my.cursework.model.Checker;
import my.cursework.model.FilesystemNode;
import my.cursework.model.MysqlManager;
import my.cursework.model.Utils;

import java.io.File;
import java.io.IOException;

public class Register extends HttpServlet {

    private String fileUploadPath;

    @Override
    public void init(ServletConfig config) throws ServletException {
        fileUploadPath = config.getServletContext().getInitParameter("FILE_UPLOAD_PATH");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("views/register.jsp");
        requestDispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        MysqlManager mysqlManager = new MysqlManager();

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String fullPath = fileUploadPath + "/" + username + "/";

        System.out.format("Requested Register with %s :: %s\n", username, password);

        if (mysqlManager.getUID(username) != 0){
            System.out.format("User with username :%s already registered\n", username);
            response.getWriter().println("ALREADY REGISTRED");
            return;
        }

        if (password == null || password.isEmpty()){
            System.out.format("empty password");
            response.getWriter().println("EMPTY PASSWORD");
            return;
        }

        if (username == null || username.isEmpty()){
            System.out.format("empty username");
            response.getWriter().println("EMPTY USERNAME");
            return;
        }

        if (!Checker.isClean(username)){
            System.out.format("Bad username");
            response.getWriter().println("BAD CHARACTESRS IN USERNAME. [a-zA-Z0-9] allowed.");
            return;
        }

        mysqlManager.addUser(username, password);

//        request.getSession();
        HttpSession session = request.getSession();
        session.setAttribute("username", username);
        int uid = mysqlManager.getUID(username);

        if (uid == 0)
            System.out.println("ERROR:Register uid is NULL");

        session.setAttribute("uid", uid);
        mysqlManager.close();
        FilesystemNode root = new FilesystemNode("root", 0);

        FilesystemNode user = new FilesystemNode(username, uid);
        FilesystemNode f = new FilesystemNode("f", uid);
        FilesystemNode f1 = new FilesystemNode("f1", uid);
        f1.setFile();
        FilesystemNode f2 = new FilesystemNode("f2", uid);
        f2.setFile();
        FilesystemNode d = new FilesystemNode("d", uid);

        user.addChild(f);
        user.addChild(f1);
        f.addChild(d);
        user.addChild(f2);
        root.addChild(user);

        System.out.println("FULLNAME : "+root.getFullName());
        System.out.println("Creating user folder::"+fullPath );
        new File(fullPath+"files/").mkdirs();
        System.out.println("Creating tree::"+root.getName());
        session.setAttribute("tree", root);
        FilesystemNode sharedRoot = new FilesystemNode("root", uid);
        FilesystemNode shared = new FilesystemNode("shared", uid);
        sharedRoot.addSharedChild(shared);

        System.out.println("Saving shared::"+fullPath+ "shared.serialized" );
        Utils.save(shared, fullPath+"shared.serialized");
        System.out.println("Saving tree::"+fullPath+ "tree.serialized" );
        Utils.save(root, fullPath+"tree.serialized");
        response.sendRedirect("./listing");
        //response.getWriter().print("The file uploaded successfully.");
    }

}
