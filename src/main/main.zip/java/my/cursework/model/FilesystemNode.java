package my.cursework.model;

import java.util.HashMap;

public class FilesystemNode implements java.io.Serializable{

    private FilesystemNode parent;
    private final String name;
    private Permissions permissions;
    private HashMap<String, FilesystemNode> children;

    private FilesystemNode sharedParent;
    private FilesystemNode publicParent;

    // Public constructors
    public FilesystemNode(String name, int uid){

        this.name = name;
        this.permissions = new Permissions(uid);

        this.parent = null;
        this.sharedParent = null;
        this.publicParent = null;
        this.children = new HashMap<>();
    }

    public FilesystemNode(String name, String uid){

        this.name = name;
        this.parent = null;
        this.sharedParent = null;
        this.publicParent = null;
        this.children = new HashMap<>();

        try {
            this.permissions = new Permissions(Integer.parseInt(uid));
        }
        catch (NumberFormatException e){
            e.printStackTrace();
            this.permissions = new Permissions(0);
        }

    }

    // Copy constructor
    public FilesystemNode(FilesystemNode other){

        if(other != null) {
            this.name = other.name;
            this.permissions = new Permissions(other.permissions);
            this.parent = other.parent;
            this.sharedParent = other.sharedParent;
            this.publicParent = other.publicParent;
            this.children = new HashMap<>();
            for(FilesystemNode node : other.children.values()){
                FilesystemNode insert = new FilesystemNode(node);
                insert.setParent(this);
                this.children.put(insert.name, insert);
            }
        }
        else {
            throw new RuntimeException("Parameter in copy constructor of FilesystemNode is null.");
        }
    }

    public void setFile(){ permissions.setIsFile(); }

    public void setDirectory(){ permissions.setIsDirectory(); }

    public boolean isFile(){ return permissions.isFile();}

    public void setParent(FilesystemNode parent){ this.parent = parent; }

    public void setPublicParent(FilesystemNode parent){ this.publicParent = parent;}

    public void setSharedParent(FilesystemNode parent){ this.sharedParent = parent;}

    public Permissions getPermissions(){
        return new Permissions(permissions);
    }

    public HashMap<String, FilesystemNode> getChildrenMap(){
        return new HashMap<>(this.children);
    }

    public FilesystemNode getParent(){
        return parent;
    }

    public String getName(){
        return name;
    }

    public String getFullName(){

//        String ans = "";
        StringBuffer sb = new StringBuffer();

        FilesystemNode parent = this;

        while(parent != null && parent.getParent() != null){

//            if (parent.getParent() == null) break;   // Why so, its redundant
//            ans = "/"+parent.getName()+ans;

            sb.insert(0, parent.getName());
            sb.insert(0, "/");
            parent = parent.getParent();
        }

        return sb.toString();
    }

    public void addChild(FilesystemNode child){

        if(child != null && !children.containsKey(child.getName()) && !this.isFile()){
            child.setParent(this);
            children.put(child.getName(), child);
        }
    }

    public void addPublicChild(FilesystemNode child){
        if(child != null && !children.containsKey(child.getName()) && !this.isFile()){
            child.setPublicParent(this);
            children.put(child.getName(), child);
        }
    }

    public void addSharedChild(FilesystemNode child){
        if(child != null && !children.containsKey(child.getName()) && !this.isFile()){
            child.setSharedParent(this);
            children.put(child.getName(), child);
        }
    }

    public void removeChild(String childName){ children.remove(childName); }

    public FilesystemNode getChild(String childName){
        return children.get(childName);
    }

    public int ChildrenSize(){
        return children.size();
    }

    public void printToHTML(StringBuffer buf, String prefix, String childrenPrefix){

        if(buf == null){
            return;
        }

        int c =0;
        buf.append(prefix);
        buf.append(name);
        buf.append(" ");


        buf.append(isFile() ? "F " : "D ");
        buf.append(permissions.toString());
        buf.append(" ");
        buf.append("<br>");

        for (FilesystemNode it: children.values()){

            c += 1;

            if (c >= children.size()){
                it.printToHTML(buf, childrenPrefix + "&#9492;&#9472;&#9472;", childrenPrefix + "&#160;&#160;&#160;");  //└──
            }
            else{
                it.printToHTML(buf, childrenPrefix + "&#9500;&#9472;&#9472;", childrenPrefix + "&#9474;&#160;&#160;"); //├──  │
            }

        }
    }

    public String printPermissions(){
        return permissions.toString();
    }

    public void printToTerminal(StringBuffer buf, String prefix, String childrenPrefix){

        if(buf == null){
            buf = new StringBuffer();
        }

        int c = 0;

        buf.append(prefix);
        buf.append(name);
        buf.append(" ");
        buf.append(permissions.getTypeString());
        buf.append("\n");

        for (FilesystemNode it: children.values()){

            c += 1;

            if (c >= children.size()){
                it.printToTerminal(buf, childrenPrefix + "└──", childrenPrefix + "   ");  //└──
            }
            else {
                it.printToTerminal(buf, childrenPrefix+"├──", childrenPrefix+"│  "); //├──  │
            }

        }
    }

    public FilesystemNode findNode(String relativePath){

        String[] splitPath = relativePath.split("/");
        FilesystemNode target = this;

        for (String it: splitPath){

            if(!it.equals("/") && !it.isEmpty()){  // There is question about 1'st statement

                target = target.getChild(it);
                System.out.println("PROC: " + it);
                if (target == null) {
                    return null;
                }
            }
        }
        return target;
    }

    @Override
    public String toString(){
        StringBuffer buf = new StringBuffer(50);
        printToHTML(buf, "", "");
        return buf.toString();
    }

    public String toStringTerminal(){
        StringBuffer buf = new StringBuffer(50);
        printToTerminal(buf, "", "");
        return buf.toString();
    }

    public FilesystemNode getSharedParent(){
        return sharedParent;
    }

    public FilesystemNode getPublicParent(){
        return publicParent;
    }

    public String getSharedFullName(){


        FilesystemNode par = this;
        StringBuffer sb = new StringBuffer();

        while (par != null && par.getSharedParent() == null){
            sb.insert(0, par.getName());
            sb.insert(0, "/");
            par = par.getParent();
        }
        while (par != null && par.getSharedParent() != null){
            sb.insert(0, par.getName());
            sb.insert(0, "/");
            par = par.getSharedParent();
        }

        return sb.toString();
    }

    public String getPublicFullName(){

        FilesystemNode par = this;
        String ans ="/"+getName();
        if (getParent() == null || getParent().getParent() == null){
            System.out.println("Null parent, return: /public");
            return "/public";
        }

        StringBuffer sb = new StringBuffer();
        sb.append("/");
        sb.append(getName());

        while (par.getPublicParent() == null){
            par = par.getParent();
            sb.insert(0, par.getName());
            sb.insert(0, "/");

            System.out.println("PFN: "+par.getName());
        }

        while( par.getPublicParent() != null){
            par = par.getPublicParent();
            sb.insert(0, par.getName());
            sb.insert(0, "/");

            System.out.println("PPFN: "+par.getName());
        }

        System.out.println("GetPublicFullName" + sb);
        return sb.toString();
    }

    public String printContent(int type){ //0-user, 1-shared, 2-public

        boolean forUser = false;
        boolean forShared = false;
        boolean forPublic = false;

        switch (type) {
            case 0:
                forUser = true;
                break;
            case 1:
                forShared= true;
                break;
            case 2:
                forPublic = true;
                break;
            default:
                break;
        }

        StringBuilder buf = new StringBuilder(50);
//        String crossImg =  "<img src=\"./Pics/cross.png\"  style=\"width:20px;height:20px;\" onclick=\"deleteFile('";
//        String shareImg =  "<img src=\"./Pics/shar.png\"  style=\"width:20px;height:20px;\" onclick=\"showShareMenu('";

        buf.append("<div class=\"current-directory\">");
        if (forUser)
            buf.append(getFullName().replace("/", " > "));

        if (forShared)
            buf.append(getSharedFullName());
        buf.append("</div>");

//        if (forUser){
//            buf.append("<button onclick=\"createDirectory('");
//            buf.append(getFullName());
//            buf.append("')\">CreateDir</button><br>");
//        }

        buf.append("<div id=\"currentDir\"  value=\"");
        buf.append(getFullName());
        buf.append("\" />");

//        if (forShared || forUser){
//
//            buf.append("<form enctype=\"multipart/form-data\" onsubmit=\"upload(false)\" target=\"dummy\" method=\"post\" action=\"\" name=\"fileupload\">");
//            buf.append("<input type=\"text\" style=\"display :none\" name=\"path\" value=\"");
//            buf.append(forUser ? getFullName() : getSharedFullName());
//            buf.append("\">");
//
//            buf.append("<input type=\"file\" name=\"file\" required />");
//            buf.append("<input type=\"submit\" value=\"Stash the file!\" action=\"submit\"/>");
//            buf.append("</form>");
//        }

        buf.append("<div class=\"file-listing\">");

        buf.append("<a class=\"go-back\" onclick=\"getPage('");
        if (forUser) {
            if (getParent() != null)
                buf.append(getParent().getFullName());
        }
        else if (forShared){
            if(getSharedParent() != null)
                buf.append(getSharedParent().getSharedFullName());
        }
        else if (forPublic){
            if (getPublicParent()!=null)
                buf.append(getPublicFullName());
        }
        buf.append("')\">..</a><br>");


        for (FilesystemNode it: children.values()){
            String name = it.getName();

            if(it.isFile()){

                buf.append("<div class=\"file\" onclick=\"downloadFile('");
                buf.append(it.getFullName());
                buf.append("', ");
                buf.append(forPublic);
                buf.append(", ");
                buf.append(forShared);
                buf.append(")\">");
//                if (!forPublic){
//                    if(forShared){
//                        buf.append("&shared=");
//                    }
//
//                    buf.append("\">");
//                }
//                else{
//                    buf.append("<a href=\"./downloadPublic?file=");
//                    buf.append(it.getFullName());
//                    buf.append("&shared=\">");
//                }
            }
            else{
                buf.append("<div class=\"folder\" id=\"dir\" onclick=\"getPage('");
                if (forUser){
                    buf.append(it.getFullName());
                }
                if (forShared){
                    buf.append(it.getSharedFullName());
                }
                if (forPublic){
                    buf.append(it.getPublicFullName());
                }
                buf.append("')\">");
            }
            buf.append(name);
            buf.append("</div>");
            buf.append("<br>");
        }
        buf.append("</div>");
        return buf.toString();
    }

    public String printConten2t(){
        StringBuilder buf = new StringBuilder(50);
        String fileImg = "<img src=\"./Pics/file.jpg\"  style=\"width:20px;height:20px;\">";
        String dirImg =  "<img src=\"./Pics/dir.png\"  style=\"width:20px;height:20px;\">";
        String crossImg =  "<img src=\"./Pics/cross.png\"  style=\"width:20px;height:20px;\" onclick=\"deleteFile(\'";
        String shareImg =  "<img src=\"./Pics/shar.png\"  style=\"width:20px;height:20px;\" onclick=\"showShareMenu(\'";
        String shareToAllIMG =  "<img src=\"./Pics/sh.png\"  style=\"width:20px;height:20px;\" onclick=\"shareToAll(\'";
        // buf.append("<script src=\"./js.js\"></script>");



        //buf.append("<div id=\"treePage\">");
        buf.append("<button onclick=\"createDirectory(\'"+getFullName()+"\')\">CreateDir</button><br>");
        //buf.append("<iframe name=\"dummy\" style=\"display:none;\"></iframe><form target= \"dummy\" method=\"post\" action=\"create\" enctype=\"multipart/form-data\"><input type=\"text\" style=\"display :none\" name=\"path\" value=\""+getFullName()+"\"><input type=\"file\" name=\"file\" /><input type=\"submit\" value=\"Upload\" onclick=\"getPage(\'"+getFullName()+"\';)\"/></form>");
        //buf.append("<iframe name=\"dummy\" style=\"display:none;\"></iframe><form target= \"dummy\" method=\"post\" action=\"create\" enctype=\"multipart/form-data\"><input type=\"text\" style=\"display :none\" name=\"path\" value=\""+getFullName()+"\"><input type=\"text\" style=\"display :none\" name=\"uid\" value=\""+uid+"\"><input type=\"file\" name=\"file\" /><input type=\"submit\" value=\"Upload\" ></form>");

        // buf.append("<iframe name=\"dummy\" style=\"display:none;\"></iframe>");
        // buf.append("<form target= \"dummy\" method=\"post\" action=\"create\" enctype=\"multipart/form-data\">");
        // buf.append("<input type=\"text\" style=\"display :none\" name=\"path\" value=\""+getFullName()+"\">");
        // buf.append("<input type=\"text\" style=\"display :none\" name=\"uid\" value=\"\">");
        // buf.append("<input type=\"file\" name=\"file\" /><input type=\"submit\" value=\"Upload\" >");
        // buf.append("</form>");
        buf.append("<div id=\"currentDir\"  value=\"" + getFullName() +"\" /></div>");
        buf.append("<form enctype=\"multipart/form-data\" onsubmit=\"upload(false)\" target=\"dummy\" method=\"post\" action=\"\" name=\"fileupload\">");
        buf.append("<input type=\"text\" style=\"display :none\" name=\"path\" value=\""+getFullName()+"\">");
        buf.append("<input type=\"file\" name=\"file\" required />");
        buf.append("<input type=\"submit\" value=\"Stash the file!\" action=\"submit\"/>");
        buf.append("</form>");

        if (getParent() != null) buf.append("<a onclick=\"getPage(\'"+getParent().getFullName()+"\')\">..</a><br>");
        for (FilesystemNode it: children.values()){
            buf.append(crossImg);
            buf.append(it.getFullName());
            buf.append("\')\"></img>");
            buf.append(shareImg);
            buf.append(it.getFullName());
            buf.append("\')\"></img>");
            buf.append(it.isFile() ? fileImg : dirImg);
            String name = it.getName();

            if(it.isFile()){
                buf.append("<a href=\"./download?file="+it.getFullName()+"\">");
            }else{
                buf.append("<a id=\"dir\" class=\"dropdown\"");
                buf.append("onclick=\"getPage(\'"+it.getFullName()+"\')\">");
            }
            buf.append(name);
            buf.append("</a>");
            buf.append(shareToAllIMG);
            buf.append(it.getFullName());
            buf.append("\')\"></img>");

            buf.append("<br>");
        }
        return buf.toString();
    }


    public String printSharedContent(){
        StringBuilder buf = new StringBuilder(50);
        String fileImg = "<img src=\"./Pics/file.jpg\"  style=\"width:20px;height:20px;\">";
        String dirImg =  "<img src=\"./Pics/dir.png\"  style=\"width:20px;height:20px;\">";
        String crossImg =  "<img src=\"./Pics/cross.png\"  style=\"width:20px;height:20px;\" onclick=\"deleteFile(\'";
        //String shareImg =  "<img src=\"./Pics/shar.png\"  style=\"width:20px;height:20px;\" onclick=\"share(\'";
        buf.append("<form enctype=\"multipart/form-data\" onsubmit=\"upload(true)\" target=\"dummy\" method=\"post\" action=\"\" name=\"fileupload\">");
        buf.append("<input type=\"text\" style=\"display :none\" name=\"path\" value=\""+getSharedFullName()+"\">");
        buf.append("<input type=\"file\" name=\"file\" required />");
        buf.append("<input type=\"submit\" value=\"Stash the file!\" action=\"submit\"/>");
        buf.append("</form>");
        buf.append("<div id=\"currentDir\"  value=\"" + getSharedFullName() +"\" />");
        if (getSharedParent() != null)
            buf.append("<a onclick=\"getPage(\'"+getSharedParent().getSharedFullName()+"\')\">..</a><br>");
        else
            buf.append("<a onclick=\"getPage(\'"+getParent().getSharedFullName()+"\')\">..</a><br>");

        for (FilesystemNode it: children.values()){
            buf.append(crossImg);
            buf.append(it.getSharedFullName());
            buf.append("\')\"></img>");
            // buf.append(shareImg);
            // buf.append(it.getSharedFullName());
            // buf.append("\')\"></img>");
            buf.append(it.isFile() ? fileImg : dirImg);
            String name = it.getName();

            if(it.isFile()){
                buf.append("<a href=\"./download?file="+it.getSharedFullName()+"&shared=\">");
            }else{
                buf.append("<a id=\"dir\" class=\"dropdown\"");
                System.out.println("Full name for "+it.getName()+" is :"+it.getSharedFullName());
                buf.append("onclick=\"getPage(\'"+it.getSharedFullName()+"\')\">");
            }
            buf.append(name);
            buf.append("</a>");

            buf.append("<br>");
        }

        return buf.toString();
    }
}
